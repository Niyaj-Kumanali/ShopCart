import React from 'react'

const PrivacyAndPolicy = () => {
  return (
    <div>PrivacyAndPolicy</div>
  )
}

export default PrivacyAndPolicy