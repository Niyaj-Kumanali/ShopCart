import { useDispatch, useSelector } from 'react-redux';
import { removeFromCart, setStoreCart, setStoreCount } from '../../store/data';

import './CartItem.css';
import { useState } from 'react';

const CartItem = ({ deal }: { deal: any }) => {
  const [count, setCount] = useState<number>(deal.quantity);
  const dispatch = useDispatch();
  const cart = useSelector((state: any) => state.cart);

  //   useEffect(() => {
  //     console.log(cart);
  //     console.log(cart.indexOf(deal));
  //   }, [cart]);

  const handleDecrease = () => {
    setCount((prev) => (prev > 1 ? prev - 1 : prev));
    dispatch(setStoreCount(deal, count - 1));
  };

  const handleIncrease = () => {
    setCount((prev) => prev + 1);
    dispatch(setStoreCount(deal, count + 1));
  };

  return (
    <div className="cartItem">
      <div className="cart-image">
        <img src={deal.thumbnail} alt={deal.title} />
      </div>
      <div className="cart-details">
        <div className="cart-title">
          <h3>{deal.title}</h3>
        </div>
        <div className="cart-price">
          <h3>${deal.price}</h3>
        </div>
        <div className="cart-description">
          <p>{deal.description}</p>
        </div>
        <div className="cart-counter">
          <button onClick={handleDecrease} className="decrease">
            -
          </button>
          <p className="product-count">{count}</p>
          <button onClick={handleIncrease} className="increase">
            +
          </button>
        </div>
        <div className="cart-btn">
          {!cart.includes(deal) ? (
            <button
              onClick={() => {
                dispatch(setStoreCart(deal));
              }}
            >
              Add to Cart
            </button>
          ) : (
            <button
              onClick={() => {
                dispatch(removeFromCart(deal.id));
              }}
            >
              Remove
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default CartItem;
