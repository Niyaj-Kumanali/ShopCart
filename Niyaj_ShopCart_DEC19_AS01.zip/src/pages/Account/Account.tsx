import React from 'react'
import './Account.css'

const Account = () => {
  return (
    <div id="Account">
        <h1>User Details</h1>
        <p><span>Name</span><span>: NIYAJ KUMANALI</span></p>
        <p><span>Email</span><span>: niyajkumanali@gmail.com</span></p>
        <p><span>Phone Number</span><span>: +918217097121</span></p>
    </div>
  )
}

export default Account