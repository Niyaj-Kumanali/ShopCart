import React from 'react'

const TermsAndConditions = () => {
  return (
    <div className="terms-and-conditions footer-link">
        <h3>Terms & Conditions</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus, rem architecto earum magni officia consequuntur ipsam, sit, voluptas qui eum accusamus perferendis! Id placeat totam aliquid quam minus tempore maxime assumenda veniam animi inventore et dolores earum commodi facilis, modi unde ducimus alias dolorum ipsum sit, itaque ratione asperiores, molestias numquam? Hic ullam eveniet officia amet iste earum, inventore excepturi cupiditate consequuntur fugiat ad vel est blanditiis harum nihil id ratione corrupti impedit animi aliquid eligendi assumenda eos. Cum neque recusandae voluptate repudiandae quam quasi nesciunt nobis exercitationem dolor. Earum perferendis cumque consequuntur corrupti? Iste quos sapiente aspernatur sint voluptatem beatae officiis tempora magni, id fuga eaque reiciendis cum consequatur molestias qui, nostrum quo.  </p>
    </div>
  )
}

export default TermsAndConditions